<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login Successful</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: Arial;
      background: #121212;
      color: white;
      text-align: center;
      padding-top: 100px;
    }
    .msg {
      background: #1e1e1e;
      padding: 30px;
      border-radius: 10px;
      display: inline-block;
    }
    a {
      color: #00ffcc;
      text-decoration: none;
      font-weight: bold;
      display: block;
      margin-top: 20px;
    }
  </style>
</head>
<body>
  <div class="msg">
    <h2>Login Successful!</h2>
    <p>You will be redirected to dashboard shortly.</p>
    <a href="dashboard.php">Go to Dashboard Now</a>
  </div>
</body>
</html>