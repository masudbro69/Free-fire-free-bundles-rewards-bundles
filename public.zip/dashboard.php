<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Free Fire Bundles</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #111;
      color: #fff;
      padding: 20px;
      text-align: center;
    }
    .bundle {
      background: #222;
      padding: 20px;
      margin: 20px auto;
      border-radius: 10px;
      max-width: 400px;
      box-shadow: 0 0 10px #0f0;
    }
    .btn {
      background: #00ff00;
      color: #000;
      padding: 10px 20px;
      border: none;
      margin-top: 10px;
      font-weight: bold;
      border-radius: 5px;
      cursor: pointer;
    }
    .btn:hover {
      background: #00cc00;
    }
  </style>
</head>
<body>
  <h1>🎁 Claim Free Fire Bundles</h1>
  
  <div class="bundle">
    <h2>Booyah Pass</h2>
    <button class="btn" onclick="window.location.href='https://swollenbasis.com/h9ij203n3?key=c53f8d3f5611ce7afa34cd2e6e97ca1b'">Claim Now</button>
  </div>

  <div class="bundle">
    <h2>999 Diamonds</h2>
    <button class="btn" onclick="window.location.href='https://swollenbasis.com/h9ij203n3?key=c53f8d3f5611ce7afa34cd2e6e97ca1b'">Claim Now</button>
  </div>

  <div class="bundle">
    <h2>Exclusive Outfit</h2>
    <button class="btn" onclick="window.location.href='https://swollenbasis.com/h9ij203n3?key=c53f8d3f5611ce7afa34cd2e6e97ca1b'">Claim Now</button>
  </div>
</body>
</html>