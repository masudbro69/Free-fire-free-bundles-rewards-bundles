<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
        body {
            background: #0d0d0d;
            color: #fff;
            font-family: sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        form {
            background: #1a1a1a;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px #00ff99;
            width: 90%;
            max-width: 400px;
        }
        input {
            display: block;
            width: 100%;
            padding: 12px;
            margin-top: 15px;
            border: none;
            background: #333;
            color: #fff;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            margin-top: 20px;
            background: #00ff99;
            color: #000;
            padding: 12px;
            border: none;
            width: 100%;
            font-weight: bold;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
        }
        h2 {
            text-align: center;
            font-size: 24px;
        }
        .error {
            color: red;
            text-align: center;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <form method="POST">
        <h2>🔐 Admin Login</h2>
        <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
        <input type="text" name="username" placeholder="Username" required />
        <input type="password" name="password" placeholder="Password" required />
        <button type="submit">Login</button>
    </form>
</body>
</html>